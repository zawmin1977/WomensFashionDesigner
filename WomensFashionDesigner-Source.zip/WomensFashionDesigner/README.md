# Women's Fashion Designer (MVP)

Android offline-first starter app for women's garment sketching.

## Included in this first build
- Burmese / English UI toggle
- Front / back garment view
- Color palette
- Freehand drawing on the design canvas
- Import a fabric image and preview it as a repeating fabric texture
- Save the design as PNG into Gallery > Pictures/WomensFashionDesigner
- Basic mannequin try-on preview (illustrative mock-up)

## Important limitations
- This first MVP does not include generative AI or realistic AI virtual try-on. Those require adding and testing a compatible on-device model, which is a separate, much larger integration and depends on device chipset/storage.
- The mannequin view is a simple preview, not a photorealistic fitting simulation.

## Build APK using GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root (not the ZIP file itself).
3. Open the **Actions** tab and choose **Build Women's Fashion Designer APK**.
4. Press **Run workflow** (or push to `main` to build automatically).
5. Open the completed workflow run, scroll to **Artifacts**, and download `WomensFashionDesigner-APK`.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on the Android phone. Allow installation from this source if Android asks.

Package: `com.womensfashiondesigner.app`
