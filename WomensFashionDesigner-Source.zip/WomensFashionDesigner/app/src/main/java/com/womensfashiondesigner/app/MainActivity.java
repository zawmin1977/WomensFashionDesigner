package com.womensfashiondesigner.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.BitmapShader;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private FashionView fashionView;
    private boolean burmese = true;
    private boolean tryOn = false;
    private int colorIndex = 0;
    private final int[] colors = new int[]{Color.rgb(190,65,92), Color.rgb(40,105,145), Color.rgb(50,135,95), Color.rgb(225,175,65), Color.rgb(115,85,150), Color.rgb(35,35,40), Color.rgb(245,220,205), Color.WHITE};
    private LinearLayout root, toolbar;
    private TextView heading, hint;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private String s(String mm, String en) { return burmese ? mm : en; }
    private TextView label(String value, int size) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(Color.rgb(45,45,55)); t.setGravity(Gravity.CENTER); return t;
    }
    private Button button(String text, Runnable action) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(12); b.setOnClickListener(v -> action.run()); return b;
    }
    private void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(10,8,10,8); root.setBackgroundColor(Color.rgb(250,247,244));
        heading = label("Women's Fashion Designer", 21); heading.setTypeface(null, Typeface.BOLD); root.addView(heading, new LinearLayout.LayoutParams(-1,48));
        hint = label(s("အင်္ကျီဒီဇိုင်းဆွဲပါ • အရောင်ရွေးပါ • သိမ်းပါ", "Design • Choose color • Save"), 13); root.addView(hint);
        fashionView = new FashionView(); LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1,0,1); vp.setMargins(0,8,0,8); root.addView(fashionView,vp);
        HorizontalScrollView paletteScroll = new HorizontalScrollView(this); LinearLayout palette = new LinearLayout(this); palette.setGravity(Gravity.CENTER_VERTICAL);
        for (int i=0;i<colors.length;i++) { final int n=i; TextView swatch = label("●",28); swatch.setTextColor(colors[i]); swatch.setPadding(9,2,9,2); swatch.setOnClickListener(v->{colorIndex=n; fashionView.invalidate();}); palette.addView(swatch); }
        paletteScroll.addView(palette); root.addView(paletteScroll,new LinearLayout.LayoutParams(-1,48));
        toolbar = new LinearLayout(this); toolbar.setOrientation(LinearLayout.HORIZONTAL); toolbar.setGravity(Gravity.CENTER); root.addView(toolbar);
        toolbar.addView(button(s("ရှေ့/နောက်", "Front/Back"),()->{fashionView.back=!fashionView.back;fashionView.invalidate();}),new LinearLayout.LayoutParams(0,55,1));
        toolbar.addView(button(s("လူပုံ", "Try-on"),()->{tryOn=!tryOn;fashionView.tryOn=tryOn;fashionView.invalidate();}),new LinearLayout.LayoutParams(0,55,1));
        toolbar.addView(button(s("ပုံဆွဲ", "Draw"),()->{fashionView.drawMode=!fashionView.drawMode;toast(s("ပုံဆွဲနိုင်ပါပြီ", "Draw on the design"));}),new LinearLayout.LayoutParams(0,55,1));
        LinearLayout second = new LinearLayout(this); second.setOrientation(LinearLayout.HORIZONTAL); root.addView(second);
        second.addView(button(s("အထည်ပုံထည့်", "Fabric photo"),()->pickFabric()),new LinearLayout.LayoutParams(0,55,1));
        second.addView(button(s("သိမ်းမယ်", "Save PNG"),()->saveImage()),new LinearLayout.LayoutParams(0,55,1));
        second.addView(button("MM / EN",()->{burmese=!burmese;buildUi();}),new LinearLayout.LayoutParams(0,55,1));
        setContentView(root);
    }
    private void toast(String m){Toast.makeText(this,m,Toast.LENGTH_SHORT).show();}
    private void pickFabric(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,41); }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==41&&resultCode==RESULT_OK&&data!=null){try{Uri u=data.getData();getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);java.io.InputStream in=getContentResolver().openInputStream(u);fashionView.fabric=BitmapFactory.decodeStream(in);fashionView.invalidate();toast(s("အထည်ပုံ ထည့်ပြီးပါပြီ", "Fabric image added"));}catch(Exception e){toast("Could not open image");}}}
    private void saveImage(){try{Bitmap b=Bitmap.createBitmap(fashionView.getWidth(),fashionView.getHeight(),Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);fashionView.draw(c);String name="FashionDesign_"+System.currentTimeMillis()+".png";android.content.ContentValues values=new android.content.ContentValues();values.put(MediaStore.Images.Media.DISPLAY_NAME,name);values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");values.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/WomensFashionDesigner");Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);OutputStream out=getContentResolver().openOutputStream(uri);b.compress(Bitmap.CompressFormat.PNG,100,out);out.close();toast(s("ပုံကို Gallery ထဲသိမ်းပြီးပါပြီ", "Saved to Gallery"));}catch(Exception e){toast("Save failed: "+e.getMessage());}}

    private class FashionView extends View {
        Paint p=new Paint(3); boolean back=false,tryOn=false,drawMode=false; Bitmap fabric; ArrayList<Path> strokes=new ArrayList<>(); Path active;
        FashionView(){super(MainActivity.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();c.drawColor(Color.WHITE);p.setColor(Color.rgb(245,239,235));p.setStyle(Paint.Style.FILL);c.drawRoundRect(8,8,w-8,h-8,24,24,p);
            if(tryOn) drawModel(c,w,h);
            float cx=w/2, top=h*.19f, shoulder=w*.23f, waist=w*.19f, hem=w*.29f;
            Path garment=new Path();garment.moveTo(cx-shoulder,top);garment.lineTo(cx-shoulder*.48f,top+8);garment.lineTo(cx-shoulder*.30f,top+ h*.10f);garment.lineTo(cx+shoulder*.30f,top+h*.10f);garment.lineTo(cx+shoulder*.48f,top+8);garment.lineTo(cx+shoulder,top);garment.lineTo(cx+waist,top+h*.36f);garment.lineTo(cx+hem,top+h*.59f);garment.quadTo(cx,top+h*.64f,cx-hem,top+h*.59f);garment.lineTo(cx-waist,top+h*.36f);garment.close();
            p.setStyle(Paint.Style.FILL); if(fabric!=null){p.setShader(new BitmapShader(Bitmap.createScaledBitmap(fabric,160,160,true),Shader.TileMode.REPEAT,Shader.TileMode.REPEAT));}else{p.setShader(null);p.setColor(colors[colorIndex]);}c.drawPath(garment,p);p.setShader(null);p.setColor(Color.rgb(65,55,58));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawPath(garment,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.rgb(250,235,220));c.drawArc(cx-shoulder*.30f,top-16,cx+shoulder*.30f,top+42,0,180,false);
            p.setColor(Color.rgb(95,75,75));p.setStrokeWidth(2);c.drawLine(cx,top+h*.12f,cx,top+h*.55f,p);c.drawLine(cx-waist*.65f,top+h*.36f,cx+waist*.65f,top+h*.36f,p);
            if(back){p.setColor(Color.WHITE);p.setStrokeWidth(4);c.drawLine(cx,top+10,cx,top+h*.57f,p);} else {p.setColor(Color.WHITE);p.setStrokeWidth(3);c.drawCircle(cx,top+h*.22f,4,p);c.drawCircle(cx,top+h*.29f,4,p);c.drawCircle(cx,top+h*.36f,4,p);}
            p.setStyle(Paint.Style.FILL);p.setColor(Color.DKGRAY);p.setTextSize(18);c.drawText(back?(burmese?"နောက်ဘက်":"BACK"):(burmese?"ရှေ့ဘက်":"FRONT"),18,35,p);
            p.setColor(Color.rgb(110,100,100));p.setTextSize(12);c.drawText(burmeseSafe(),18,h-18,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(Color.rgb(40,40,40));for(Path path:strokes)c.drawPath(path,p);if(active!=null)c.drawPath(active,p);p.setStyle(Paint.Style.FILL);
        }
        private String burmeseSafe(){return tryOn?(burmese?"လူပုံပေါ် စမ်းဝတ်ကြည့်ခြင်း":"MODEL TRY-ON"):(burmese?"အင်္ကျီဒီဇိုင်း":"GARMENT DESIGN");}
        private void drawModel(Canvas c,float w,float h){float x=w/2,y=h*.13f;p.setColor(Color.rgb(215,180,155));p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,27,p);p.setColor(Color.rgb(95,70,65));c.drawOval(x-29,y-33,x+29,y+5,p);p.setColor(Color.rgb(215,180,155));c.drawRoundRect(x-13,y+18,x+13,y+52,8,8,p);p.setColor(Color.rgb(225,205,190));c.drawRoundRect(x-75,y+50,x+75,h*.86f,45,35,p);p.setColor(Color.rgb(220,195,180));c.drawRoundRect(x-92,y+65,x-70,h*.65f,12,12,p);c.drawRoundRect(x+70,y+65,x+92,h*.65f,12,12,p);}
        @Override public boolean onTouchEvent(MotionEvent e){if(!drawMode)return true;float x=e.getX(),y=e.getY();switch(e.getAction()){case MotionEvent.ACTION_DOWN:active=new Path();active.moveTo(x,y);invalidate();return true;case MotionEvent.ACTION_MOVE:if(active!=null){active.lineTo(x,y);invalidate();}return true;case MotionEvent.ACTION_UP:if(active!=null){strokes.add(active);active=null;invalidate();}return true;}return true;}
    }
}
